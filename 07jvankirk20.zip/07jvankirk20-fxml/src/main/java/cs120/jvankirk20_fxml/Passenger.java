package cs120.jvankirk20_fxml;

import javafx.beans.property.SimpleDoubleProperty;

/**
 * 
 * Holds all the information about a passenger on the titanic, including age, cabin, embarked, fare, name, parch, passengerID, pClass, sex, sibSp, survived, ticket, title, and family size.
 * @author jaidynvankirk
 *
 */

public class Passenger {
	Double age;
	String cabin;
	String embarked;
	Double fare;
	String name;
	Double parch;
	Double passengerID;
	Double pClass;
	String sex;
	Double sibSp;
	Double survived;
	String ticket;
	String title;
	Double familySize;
	
	/*
	 * No argument constructor. Every passenger will start out with this, and then use setters to fill in their information.
	 */
	public Passenger() {
		age = new Double(0);
		fare = new Double(0);
		parch = new Double(0);
		passengerID = new Double(0);
		pClass = new Double(0);
		sibSp = new Double(0);
		survived = new Double(0);
		familySize = new Double(0);
	}
	
	/*
	 * Setters for all of our properties that come with a new Passenger.
	 */
	public void setAge(Double age) {
		this.age = age;
	}
	public void setCabin(String cabin) {
		this.cabin = cabin;
	}
	public void setEmbarked(String embarked) {
		this.embarked = embarked;
	}
	public void setFare(Double fare) {
		this.fare = fare;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setParch (Double parch) {
		this.parch = parch;
	}
	public void setPassengerID(Double passengerID) {
		this.passengerID = passengerID;
	}
	public void setPClass(Double pClass) {
		this.pClass = pClass;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public void setSibSp(Double sibSp) {
		this.sibSp = sibSp;
	}
	public void setSurvived(Double survived) {
		this.survived = survived;
	}
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setFamilySize(Double familySize) {
		this.familySize = familySize;
	}
	
	/*
	 * Getters for all of our properties that come with a new Passenger.
	 */
	public double getAge() {
		return age.doubleValue();
	}
	public String getCabin() {
		return cabin;
	}
	public String getEmbarked() {
		return embarked;
	}
	public double getFare() {
		return fare.doubleValue();
	}
	public String getName() {
		return name;
	}
	public double getParch() {
		return parch.doubleValue();
	}
	public double getPassengerID() {
		return passengerID.doubleValue();
	}
	public double getPClass() {
		return pClass.doubleValue();
	}
	public String getSex() {
		return sex;
	}
	public double getSibSp() {
		return sibSp.doubleValue();
	}
	public double getSurvived() {
		return survived.doubleValue();
	}
	public String getTicket() {
		return ticket;
	}
	public String getTitle() {
		return title;
	}
	public double getFamilySize() {
		return familySize.doubleValue();
	}
}
