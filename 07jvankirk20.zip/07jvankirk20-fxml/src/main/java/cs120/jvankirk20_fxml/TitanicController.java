package cs120.jvankirk20_fxml;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TitanicController {
	TitanicIO tcio;
    List<Passenger> pLst;
    /*
     * All of the passenger properties that are binded with the text boxes and combo box to create a new passenger.
     */
    StringProperty newAge;
	StringProperty newCabin;
	StringProperty newEmbarked;
	StringProperty newFare;
	StringProperty newName;
	StringProperty newParch;
	StringProperty newPassengerID;
	StringProperty newPClass;
	StringProperty newSex;
	StringProperty newSibSp;
	StringProperty newSurvived;
	StringProperty newTicket;
	StringProperty newTitle;
	StringProperty newFamilySize;
    /*
     * All of the passenger properties that are binded with the text boxes and combo box to give information and update information about a current passenger.
     */
    StringProperty age;
	StringProperty cabin;
	StringProperty embarked;
	StringProperty fare;
	StringProperty name;
	StringProperty parch;
	StringProperty passengerID;
	StringProperty pClass;
	StringProperty sex;
	StringProperty sibSp;
	StringProperty survived;
	StringProperty ticket;
	StringProperty title;
	StringProperty familySize;
	
	visualCalc vC;									//Our component that handles all the calculations.
	StringProperty totalPass;						//Holds the number of passengers we have binded to a text box that displays this.
	
	double totalFemaleSurvivors;				//Holds the amount of female survivors.
	double totalMaleSurvivors;					//Holds the amount of male survivors.
	double class1;								//Holds the percentage of class 1 survivors.
	double class2;								//Holds the percentage of class 2 survivors.
	double class3;								//Holds the percentage of class 3 survivors.
	List<FamilySizes> sizeTracker;				//Holds the group information pertaining to family sizes.
    
    public TitanicController() {
    	tcio = new TitanicIO();					//Creates our reader and writer filer.
        pLst = tcio.fileReadIn();				//Gets the passengers out of our file.
       /*
        * Initializes all of our properties that are used to create a new passenger.
        */
        newAge = new SimpleStringProperty();
        newCabin = new SimpleStringProperty();
        newEmbarked = new SimpleStringProperty();
        newFare = new SimpleStringProperty();
        newName = new SimpleStringProperty();
        newParch = new SimpleStringProperty();
        newPassengerID = new SimpleStringProperty();
        newPClass = new SimpleStringProperty();
        newSex = new SimpleStringProperty();
        newSibSp = new SimpleStringProperty();
        newSurvived = new SimpleStringProperty();
        newTicket = new SimpleStringProperty();
        newTitle = new SimpleStringProperty();
        newFamilySize = new SimpleStringProperty();
        /*
         * Initializes all of our passenger properties on the main pane.
         */
        age = new SimpleStringProperty();
        cabin = new SimpleStringProperty();
        embarked = new SimpleStringProperty();
        fare = new SimpleStringProperty();
        name = new SimpleStringProperty();
        parch = new SimpleStringProperty();
        passengerID = new SimpleStringProperty();
        pClass = new SimpleStringProperty();
        sex = new SimpleStringProperty();
        sibSp = new SimpleStringProperty();
        survived = new SimpleStringProperty();
        ticket = new SimpleStringProperty();
        title = new SimpleStringProperty();
        familySize = new SimpleStringProperty();
        
        vC = new visualCalc();						//Initializes our calculator.
        
        totalPass = new SimpleStringProperty();			//Initalizes our total passenger property.
        totalFemaleSurvivors = getTotalFemaleSurvivors();			//Gets the total number of female survivors.
        totalMaleSurvivors = getTotalMaleSurvivors();				//Gets the total number of male survivors.
        /*
         * Gets our class percentages from our calculator.
         */
        class1 = vC.getClass1();
        class2 = vC.getClass2();
        class3 = vC.getClass3();
    }
    /*
     * Does some necessary inital calculations for the information on the right side of the screen.
     */
    public void firstPassCount() {
    	totalPass.setValue(Double.toString(vC.totalPassengers(pLst)));			//Gets our total passengers from our calculator.
    	/*
    	 * Gets the male and female amounts from our calculator.
    	 */
    	totalFemaleSurvivors = vC.femaleSurvivors(pLst);
    	totalMaleSurvivors = vC.maleSurvivors(pLst);
    	/*
    	 * Calculates and updates our class values.
    	 */
    	vC.survivorsByClass(pLst);
        class1 = vC.getClass1();
        class2 = vC.getClass2();
        class3 = vC.getClass3();
        
        sizeTracker = vC.survivorsByFamilySize(pLst);			//Calculates the items for our groups pertaining to family sizes.
    }
    /*
     * Getters for our pie chart and bar graph element.
     */
    public double getTotalFemaleSurvivors() {
    	return totalFemaleSurvivors;
    }
    
    public double getTotalMaleSurvivors() {
    	return totalMaleSurvivors;
    }
    
    public double getClass1() {
    	return class1;
    }
    public double getClass2() {
    	return class2;
    }
    public double getClass3() {
    	return class3;
    }
    public List<FamilySizes> survivorsByFamilySize(){
    	return sizeTracker;
    }
	/*
	 * Returns our passenger list.
	 */
	public List<Passenger> getPassengerList() {
		return pLst;
	}
	
	/*
	 * Creates a new passenger with the proper material. Adds them to our list. Updates our graph information.
	 */
	public Passenger newPassenger() {
		Passenger newP = new Passenger();		//Creates new passenger.
		/*
		 * Updates the passenger elements with user provided information. Uses catch clauses to make sure numbers go where numbers are supposed to be,.
		 */
		try {
			newP.setAge(Double.parseDouble(newAge.get()));
		} catch (Exception e){
			Double replacementAge = new Double(0);
			newP.setAge(replacementAge);
		}
		newP.setCabin(newCabin.get());
		newP.setEmbarked(newEmbarked.get());
		try {
			newP.setFare(Double.parseDouble(newFare.get()));
		} catch (Exception e){
			Double replacementFare = new Double(0);
			newP.setFare(replacementFare);
		}
		newP.setName(newName.get());
		try {
			newP.setParch(Double.parseDouble(newParch.get()));
		} catch (Exception e){
			Double replacementParch = new Double(0);
			newP.setParch(replacementParch);
		}
		newP.setName(newName.get());
		try {
			newP.setPassengerID(Double.parseDouble(newPassengerID.get()));
		} catch (Exception e){
			Double replacementPassengerID = new Double(0);
			newP.setPassengerID(replacementPassengerID);
		}
		try {
			newP.setPClass(Double.parseDouble(newPClass.get()));
		} catch (Exception e){
			Double replacementPClass = new Double(0);
			newP.setPClass(replacementPClass);
		}
		newP.setSex(newSex.get());
		try {
			newP.setSibSp(Double.parseDouble(newSibSp.get()));
		} catch (Exception e){
			Double replacementSibSp = new Double(0);
			newP.setSibSp(replacementSibSp);
		}
		try {
			newP.setSurvived(Double.parseDouble(newSurvived.get()));
		} catch (Exception e){
			Double replacementSurvived = new Double(0);
			newP.setSurvived(replacementSurvived);
		}
		newP.setTicket(newTicket.get());
		newP.setTitle(newTitle.get());
		try {
			newP.setFamilySize(Double.parseDouble(newFamilySize.get()));
		} catch (Exception e){
			Double replacementFamilySize = new Double(0);
			newP.setFamilySize(replacementFamilySize);
		}
		/*
		 * Updates our passenger list and calculated elements.
		 */
		tcio.updateTitanicFile(pLst);
		totalPass.setValue(Double.toString(vC.addPass()));
		totalFemaleSurvivors = vC.addFemaleSurvivor(newP);
		totalMaleSurvivors = vC.addMaleSurvivor(newP);
    	vC.survivorsByClass(pLst);
        class1 = vC.getClass1();
        class2 = vC.getClass2();
        class3 = vC.getClass3();
        sizeTracker = vC.survivorsByFamilySize(pLst);
		return newP;
	}
	
	/*
	 * Updates our main pane's text boxes with the proper information when a passenger is selected.
	 */
	public void selectedPassengerAction(String name) {
		/*
		 * Finds the proper passenger.
		 */
		int selectedIndex = 0;
		for (int i = 0; i < pLst.size(); i++) {
			if((name.compareTo(pLst.get(i).getName())) == 0) {
				selectedIndex = i;
			}
		}
		/*
		 * Updates the binded values with the passenger's values.
		 */
		age.setValue(Double.toString(pLst.get(selectedIndex).getAge()));
		cabin.setValue(pLst.get(selectedIndex).getCabin());
		embarked.setValue(pLst.get(selectedIndex).getEmbarked());
		fare.setValue(Double.toString(pLst.get(selectedIndex).getFare()));
        this.name.setValue(pLst.get(selectedIndex).getName());
		parch.setValue(Double.toString(pLst.get(selectedIndex).getParch()));
		passengerID.setValue(Double.toString(pLst.get(selectedIndex).getPassengerID()));
		pClass.setValue(Double.toString(pLst.get(selectedIndex).getPClass()));
		sex.setValue(pLst.get(selectedIndex).getSex());
		sibSp.setValue(Double.toString(pLst.get(selectedIndex).getSibSp()));
		survived.setValue(Double.toString(pLst.get(selectedIndex).getSurvived()));
		ticket.setValue(pLst.get(selectedIndex).getTicket());
		title.setValue(pLst.get(selectedIndex).getTitle());
		familySize.setValue(Double.toString(pLst.get(selectedIndex).getFamilySize()));
	}
	/*
	 * Used when a passenger is officially deleted. Rids them from our list and updates our calculations.
	 */
	public void deleteButtonAction(String name) {
		/*
		 * Finds the proper passenger.
		 */
		int selectedIndex = 0;
		for (int i = 0; i < pLst.size(); i++) {
			if((name.compareTo(pLst.get(i).getName())) == 0) {
				selectedIndex = i;
			}
		}
		/*
		 * Removes from our passenger list and updates our calculated values.
		 */
		pLst.remove(selectedIndex);
		totalFemaleSurvivors = vC.deleteFemaleSurvivor(pLst.get(selectedIndex));
		totalMaleSurvivors = vC.deleteMaleSurvivor(pLst.get(selectedIndex));
		tcio.updateTitanicFile(pLst);;
		totalPass.setValue(Double.toString(vC.deletePass()));
    	vC.survivorsByClass(pLst);
        class1 = vC.getClass1();
        class2 = vC.getClass2();
        class3 = vC.getClass3();
        sizeTracker = vC.survivorsByFamilySize(pLst);
	}
	/*
	 * Updates the current selected passengers values with the values on the main pane.
	 */
	public void saveChangesButtonAction(String name) {
		/*
		 * Finds the proper passenger.
		 */
		int selectedIndex = 0;
		for (int i = 0; i < pLst.size(); i++) {
			if((name.compareTo(pLst.get(i).getName())) == 0) {
				selectedIndex = i;
			}
		}
		/*
		 * Updates all the properties of the passenger.
		 */
		pLst.get(selectedIndex).setAge(Double.parseDouble(age.get()));
		pLst.get(selectedIndex).setCabin(cabin.get());
		pLst.get(selectedIndex).setEmbarked(embarked.get());
		pLst.get(selectedIndex).setFare(Double.parseDouble(fare.get()));
		pLst.get(selectedIndex).setName(this.name.get());
		pLst.get(selectedIndex).setParch(Double.parseDouble(parch.get()));
		pLst.get(selectedIndex).setPassengerID(Double.parseDouble(passengerID.get()));
		pLst.get(selectedIndex).setPClass(Double.parseDouble(pClass.get()));
		pLst.get(selectedIndex).setSex(sex.get());
		pLst.get(selectedIndex).setSibSp(Double.parseDouble(sibSp.get()));
		pLst.get(selectedIndex).setSurvived(Double.parseDouble(survived.get()));
		pLst.get(selectedIndex).setTicket(ticket.get());
		pLst.get(selectedIndex).setTitle(title.get());
		pLst.get(selectedIndex).setFamilySize(Double.parseDouble(familySize.get()));
		
		tcio.updateTitanicFile(pLst);;		//Updates our file.
		/*
		 * Updates our calculated values.
		 */
		if ((pLst.get(selectedIndex).getSex().compareTo("male")) == 0) {
			totalMaleSurvivors = vC.addMaleSurvivor(pLst.get(selectedIndex));
			totalFemaleSurvivors = vC.deleteFemaleSurvivor(pLst.get(selectedIndex));
		} else {
			totalFemaleSurvivors = vC.addFemaleSurvivor(pLst.get(selectedIndex));
			totalMaleSurvivors = vC.deleteMaleSurvivor(pLst.get(selectedIndex));
		}
    	vC.survivorsByClass(pLst);
        class1 = vC.getClass1();
        class2 = vC.getClass2();
        class3 = vC.getClass3();
        sizeTracker = vC.survivorsByFamilySize(pLst);
		
	}
}
