package cs120.jvankirk20_fxml;

/**
 * 
 * Holds the information that correlates the surviving members to their family sizes.
 * @author jaidynvankirk
 *
 */

public class FamilySizes {
	String numberString;														//String of the number
	double number;																//The number of family members this group represents.
	double total;																//The total number of people in the group.
	double percentage;															//The percentage of people out of the total number of people who survived who have this many family members.
	/*
	 * Creates a new family size group. It creates a string of the number of family members, holds the double version of the amount of family member's, starts the group with one member, and
	 * gets the population of surviving members and divides it by our total to get the percentage.
	 */
	public FamilySizes(String numberString, double number, double pop) {
		this.numberString = numberString;
		this.number = number;
		total = 1;
		percentage = total/pop;
	}
	
	/*
	 * Allows access to the amount of family members this FamilySizes group represents.
	 */
	public double getNumber() {
		return number;
	}
	
	/*
	 * Adds some one to the group, then divides the new total by the surviving group population to get the updated percentage.
	 */
	public void addPerson(double pop) {
		total++;
		percentage = total/pop;
	}
	
	/*
	 * Allows access to the String version of the amount of family members in this group.
	 */
	public String getNumberString() {
		return numberString;
	}
	
	/*
	 * Allows access to the current percentage that we have.
	 */
	public double getPercentage() {
		return percentage;
	}
}
