package cs120.jvankirk20_fxml;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.Property;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DialogPane;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

/**
 * 
 * The Primary Controller for all of our human interface components. All changes and actions start here.
 * @author jaidynvankirk
 *
 */

public class PrimaryController implements Initializable{

	TitanicController tc;									//Our controller that handles the more analytical components.
	List<Passenger> pLst;									//Holds our updated list of passengers that we have.
	String selectedName;									//Holds the name that the list has currently selected.
	
	
	/*
	 * All of our human interface components.
	 */
    @FXML
    ListView<String> passengerList;
    @FXML
    DialogPane addNewPassengerPane;
    @FXML
    Button addButton;
    @FXML 
    Button createButton;
    @FXML
    Button cancelButton;
    @FXML
    TextField newAgeText;
    @FXML
    TextField newCabinText;
    @FXML
    TextField newEmbarkedText;
    @FXML
    TextField newFareText;
    @FXML
    TextField newNameText;
    @FXML
    TextField newParchText;
    @FXML
    TextField newPassengerIDText;
    @FXML
    TextField newPClassText;
    @FXML
    ChoiceBox newSexText;
    @FXML
    TextField newSibSpText;
    @FXML
    TextField newSurvivedText;
    @FXML
    TextField newTicketText;
    @FXML
    TextField newTitleText;
    @FXML
    TextField newFamilySizeText;
    @FXML
    VBox originalVBox;
    @FXML
    TextField ageText;
    @FXML
    TextField cabinText;
    @FXML
    TextField embarkedText;
    @FXML
    TextField fareText;
    @FXML
    TextField nameText;
    @FXML
    TextField parchText;
    @FXML
    TextField passengerIDText;
    @FXML
    TextField pClassText;
    @FXML
    ChoiceBox sexText;
    @FXML
    TextField sibSpText;
    @FXML
    TextField survivedText;
    @FXML
    TextField ticketText;
    @FXML
    TextField titleText;
    @FXML
    TextField familySizeText;
    @FXML
    DialogPane deletePane;
    @FXML
    TextField totalNumberOfPassengers;
    @FXML
    PieChart genderOfSurvivors;
    @FXML
    BarChart percentageOfSurvivorsByClass;
    @FXML
    BarChart percentageOfSurvivorsByFS;
    
    ObservableList<PieChart.Data> survivorsGender;						//Holds our data for the pie chart that compares female to male survivors.
    ObservableList<XYChart.Data> survivorsClass;						//Holds our data that compares the classes of our surviving members.
    ObservableList<XYChart.Data> survivorsByFamily;						//Holds our data that compares the amount of family members the surviving members had.
    
    List<FamilySizes> famLst;											//Holds the list that divides the surviving group by the amount of family members each of them has.
    
    /*
     * We bind a lot of our properties and initialize important components of our program.
     */
    @Override
	public void initialize(URL location, ResourceBundle resources) {
		tc = new TitanicController();										//Initializes our controller.
		pLst = tc.getPassengerList();										//Initializes our passenger list
		/*
		 * Fills our list on the left with the names of our passengers.
		 */
		for(int i = 0; i < pLst.size(); i++) {
			passengerList.getItems().add(pLst.get(i).getName());
		}
		/*
		 * Sets the appropriate pane(the original panel) to visible and others to false.
		 */
		addNewPassengerPane.setVisible(false);
		originalVBox.setVisible(true);
		deletePane.setVisible(false);
		
		/*
		 * Adds the option of female or male to our choice box that is connected to the list item that is picked.
		 */
		newSexText.getItems().add("female");
		newSexText.getItems().add("male");
		/*
		 * Adds the option of female or male to our choice box to create a new passenger.
		 */
		sexText.getItems().add("female");
		sexText.getItems().add("male");
		/*
		 * Binds all our properties to create a new passenger with the proper text fields and combo box.
		 */
		tc.newAge.bind(newAgeText.textProperty());
		tc.newCabin.bind(newCabinText.textProperty());
		tc.newEmbarked.bind(newEmbarkedText.textProperty());
		tc.newFare.bind(newFareText.textProperty());
		tc.newName.bind(newNameText.textProperty());
		tc.newParch.bind(newParchText.textProperty());
		tc.newPassengerID.bind(newPassengerIDText.textProperty());
		tc.newPClass.bind(newPClassText.textProperty());
		tc.newSex.bind(newSexText.getSelectionModel().selectedItemProperty());
		tc.newSibSp.bind(newSibSpText.textProperty());
		tc.newSurvived.bind(newSurvivedText.textProperty());
		tc.newTicket.bind(newTicketText.textProperty());
		tc.newTitle.bind(newTitleText.textProperty());
		tc.newFamilySize.bind(newFamilySizeText.textProperty());
		/*
		 * Binds all our properties of the current passenger picked to our text fields and combo boxes on the main screen.
		 */
		tc.age.bindBidirectional(ageText.textProperty());
		tc.cabin.bindBidirectional(cabinText.textProperty());
		tc.embarked.bindBidirectional(embarkedText.textProperty());
		tc.fare.bindBidirectional(fareText.textProperty());
		tc.name.bindBidirectional(nameText.textProperty());
		tc.parch.bindBidirectional(parchText.textProperty());
		tc.passengerID.bindBidirectional(passengerIDText.textProperty());
		tc.pClass.bindBidirectional(pClassText.textProperty());
		tc.sibSp.bindBidirectional(sibSpText.textProperty());
		tc.survived.bindBidirectional(survivedText.textProperty());
		tc.ticket.bindBidirectional(ticketText.textProperty());
		tc.title.bindBidirectional(titleText.textProperty());
		tc.familySize.bindBidirectional(familySizeText.textProperty());
		
		tc.totalPass.bindBidirectional(totalNumberOfPassengers.textProperty());						//Binds the text field that shows the amount of passengers with the total amount calculated.
		totalNumberOfPassengers.setDisable(true);													//Sets that text box to diabled.
		tc.firstPassCount();																		//The initial calculation of some of our analytical components. More in Titanic Controller.
		/*
		 * Gets the amount of female and male survivors and puts that into our Pie Chart.
		 */
		survivorsGender = FXCollections.observableArrayList(
			new PieChart.Data("Female", tc.getTotalFemaleSurvivors()),
			new PieChart.Data("Male", tc.getTotalMaleSurvivors())
		);
		genderOfSurvivors.setData(survivorsGender);
		/*
		 * Gets the calculated percentages of what survivors were in each class and puts that into our bar graph.
		 */
		XYChart.Series survivorsClass = new XYChart.Series();
		survivorsClass.getData().add(new XYChart.Data("Class 1", tc.getClass1()));
		survivorsClass.getData().add(new XYChart.Data("Class 2", tc.getClass2()));
		survivorsClass.getData().add(new XYChart.Data("Class 3", tc.getClass3()));
		percentageOfSurvivorsByClass.getData().add(survivorsClass);
		/*
		 * Uses a for loop to get all the different groups of family member numbers and their percentages. Puts that into our bar graph that shows the percentages of how many family members
		 * the survivors had.
		 */
		XYChart.Series familyClass = new XYChart.Series();
		famLst = tc.survivorsByFamilySize();
		for(int i = 0; i < famLst.size(); i ++) {
			familyClass.getData().add(new XYChart.Data(famLst.get(i).getNumberString(), famLst.get(i).getPercentage()));
		}
		percentageOfSurvivorsByFS.getData().add(familyClass);
	}
    /*
     * On the add button sets our add person pane to visible and our main pane to false.
     */
	@FXML
	public void addButtonAction() {
		addNewPassengerPane.setVisible(true);
		originalVBox.setVisible(false);
	}
	/*
	 * On the create a passenger panel their is a cancel button. When this is clicked it sets the create pane to invisible and our main pane to visible.
	 */
	@FXML
	public void cancelButton() {
		addNewPassengerPane.setVisible(false);
		originalVBox.setVisible(true);
	}
	/*
	 * Activated when the create button is hit on the create new passenger pane. Basically uses the Titanic controller to create a new passenger, adds the new person to our list, and updates our graphs.
	 */
	@FXML
	public void createButton() {
		addNewPassengerPane.setVisible(false);													//Sets our add create new passenger pane to invisible.
		Passenger newP = tc.newPassenger();														//Uses the titanic controller to create our passenger.
		pLst.add(newP);																			//Adds the new passenger onto our array list.
		passengerList.getItems().add(newP.getName());											//Adds the new passengers name onto our selection list.
		/*
		 * Updates our gender pie chart with the new passenger.
		 */
		survivorsGender = FXCollections.observableArrayList(
				new PieChart.Data("Female", tc.getTotalFemaleSurvivors()),
				new PieChart.Data("Male", tc.getTotalMaleSurvivors())
			);
		genderOfSurvivors.setData(survivorsGender);
		/*
		 * Removes the intial bars on our graph pertaining to classes and replaces them with the new percentages.
		 */
		XYChart.Series survivorsClass = new XYChart.Series();
		percentageOfSurvivorsByClass.getData().remove(0);
		survivorsClass.getData().add(new XYChart.Data("Class 1", tc.getClass1()));
		survivorsClass.getData().add(new XYChart.Data("Class 2", tc.getClass2()));
		survivorsClass.getData().add(new XYChart.Data("Class 3", tc.getClass3()));
		percentageOfSurvivorsByClass.getData().add(survivorsClass);
		/*
		 * Removes the intial bars on our graph peraining to number of family members and replaces them with the new percentages.
		 */
		percentageOfSurvivorsByFS.getData().remove(0);
		XYChart.Series familyClass = new XYChart.Series();
		famLst = tc.survivorsByFamilySize();
		for(int i = 0; i < famLst.size(); i ++) {
			familyClass.getData().add(new XYChart.Data(famLst.get(i).getNumberString(), famLst.get(i).getPercentage()));
		}
		percentageOfSurvivorsByFS.getData().add(familyClass);
		
		originalVBox.setVisible(true);															//Sets our main pane to visible.
	}
	/*
	 * When a name is selected off of the list, this method gets it and gives it to Titanic controller so it can set the values in the main pane properly. Also sets the sex box.
	 */
	@FXML
	public void selectPassenger() {
		selectedName = passengerList.getSelectionModel().getSelectedItem();
		tc.selectedPassengerAction(selectedName);
		sexText.setValue(tc.sex.get());
	}
	/*
	 * Hides our main pane and shows a pane asking if you are sure you want to delete a passenger.
	 */
	@FXML
	public void deleteButton() {
		deletePane.setVisible(true);
		originalVBox.setVisible(false);
	}
	/*
	 * When no is clicked it hides our are you sure pane and replaces it with our main pane.
	 */
	public void noButton() {
		deletePane.setVisible(false);
		originalVBox.setVisible(true);
	}
	/*
	 * This deletes the proper person off of our list using Titanic Controller, and then repopulates the list without the person. It also updates our graph and pie chart.
	 */
	public void yesButton() {
		tc.deleteButtonAction(selectedName);							//deletes using titanic controller
		/*
		 * Removes the items off of our list
		 */
		for(int i = 0; i < pLst.size(); i++) {
			passengerList.getItems().remove(pLst.get(i).getName());
		}
		pLst = tc.getPassengerList();										//Gets the correct passenger array list from our titanic controller.
		/*
		 * Repopulates our list with the correct names.
		 */
		for(int i = 0; i < pLst.size(); i++) {
			passengerList.getItems().add(pLst.get(i).getName());
		}
		deletePane.setVisible(false);								//Makes our delete pane invisbile
		originalVBox.setVisible(true);								//Makes our main pane visible.
		/*
		 * Updates our pie chart.
		 */
		survivorsGender = FXCollections.observableArrayList(
				new PieChart.Data("Female", tc.getTotalFemaleSurvivors()),
				new PieChart.Data("Male", tc.getTotalMaleSurvivors())
			);
		genderOfSurvivors.setData(survivorsGender);
		/*
		 * Removes and updates values on our bar chart pertaining to classes.
		 */
		XYChart.Series survivorsClass = new XYChart.Series();
		percentageOfSurvivorsByClass.getData().remove(0);
		survivorsClass.getData().add(new XYChart.Data("Class 1", tc.getClass1()));
		survivorsClass.getData().add(new XYChart.Data("Class 2", tc.getClass2()));
		survivorsClass.getData().add(new XYChart.Data("Class 3", tc.getClass3()));
		percentageOfSurvivorsByClass.getData().add(survivorsClass);
		/*
		 * Removes and updates our bar graph pertaining to amount of family members.
		 */
		percentageOfSurvivorsByFS.getData().remove(0);
		XYChart.Series familyClass = new XYChart.Series();
		famLst = tc.survivorsByFamilySize();
		for(int i = 0; i < famLst.size(); i ++) {
			familyClass.getData().add(new XYChart.Data(famLst.get(i).getNumberString(), famLst.get(i).getPercentage()));
		}
		percentageOfSurvivorsByFS.getData().add(familyClass);
	}
	//Uses Titanic controller to update the selected passenger. Then updates our array list with correct names. Then we update our graphs.
	public void saveChangesButton() {
		tc.saveChangesButtonAction(selectedName);											//Uses titanic controller to update the selected passenger.
		/*
		 * Removes the list of names, gets the updated names, and repopulates the list.
		 */
		for(int i = 0; i < pLst.size(); i++) {
			passengerList.getItems().remove(pLst.get(i).getName());
		}
		pLst = tc.getPassengerList();
		for(int i = 0; i < pLst.size(); i++) {
			passengerList.getItems().add(pLst.get(i).getName());
		}
		
		deletePane.setVisible(false);							//Sets the delete pane to invisible.
		originalVBox.setVisible(true);							//Sets the mane pane to visible.
		/*
		 * Updates our pie chart.
		 */
		survivorsGender = FXCollections.observableArrayList(
				new PieChart.Data("Female", tc.getTotalFemaleSurvivors()),
				new PieChart.Data("Male", tc.getTotalMaleSurvivors())
			);
		genderOfSurvivors.setData(survivorsGender);
		/*
		 * Updates our bar graph pertaining to class.
		 */
		XYChart.Series survivorsClass = new XYChart.Series();
		percentageOfSurvivorsByClass.getData().remove(0);
		survivorsClass.getData().add(new XYChart.Data("Class 1", tc.getClass1()));
		survivorsClass.getData().add(new XYChart.Data("Class 2", tc.getClass2()));
		survivorsClass.getData().add(new XYChart.Data("Class 3", tc.getClass3()));
		percentageOfSurvivorsByClass.getData().add(survivorsClass);
		/*
		 * Updates our bar graph pertaining to family members.
		 */
		percentageOfSurvivorsByFS.getData().remove(0);
		XYChart.Series familyClass = new XYChart.Series();
		famLst = tc.survivorsByFamilySize();
		for(int i = 0; i < famLst.size(); i ++) {
			familyClass.getData().add(new XYChart.Data(famLst.get(i).getNumberString(), famLst.get(i).getPercentage()));
		}
		percentageOfSurvivorsByFS.getData().add(familyClass);
	}
}
