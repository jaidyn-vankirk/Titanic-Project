package cs120.jvankirk20_fxml;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class TitanicIO {
	File titanicTxt = new File("./titanic.txt");
	List<Passenger> lst;
	FileWriter fw;
	/*
	 * Reads in a line, splits it where it needs to, and returns a passenger.
	 */
	private Passenger passengerReadIn(String line) {
		String[] parts = line.trim().split("[|]");
		Passenger nP = new Passenger();			//Creates passenger
		/*
		 * Sets the passengers properties with those read in.
		 */
		nP.setAge(Double.parseDouble(parts[0]));
		nP.setCabin(parts[1].trim());
		nP.setEmbarked(parts[2].trim());
		nP.setFare(Double.parseDouble(parts[3]));
		nP.setName(parts[4].trim());
		nP.setParch(Double.parseDouble(parts[5]));
		nP.setPassengerID(Double.parseDouble(parts[6]));
		nP.setPClass(Double.parseDouble(parts[7]));
		nP.setSex(parts[8].trim());
		nP.setSibSp(Double.parseDouble(parts[9]));
		nP.setSurvived(Double.parseDouble(parts[10]));
		nP.setTicket(parts[11].trim());
		nP.setTitle(parts[12].trim());
		nP.setFamilySize(Double.parseDouble(parts[13]));
		
		return nP;
	}
	/*
	 * Puts passengers in proper format to be written into a file.
	 */
	private String getFormattedPassengerInfo (Passenger p) {
		String writeIn = (p.getAge() + "|" + p.getCabin() + "|" + p.getEmbarked() + "|" + p.getFare() + "|" + p.getName() + "|" + p.getParch() + "|" + p.getPassengerID() + "|" + p.getPClass() + "|" + p.getSex() + "|" + p.getSibSp() + "|" + p.getSurvived() + "|" + p.getTicket() + "|" + p.getTitle() + "|" + p.getFamilySize());
		return writeIn;
	}
	/*
	 * Reads in the passengers.
	 */
	public List<Passenger> fileReadIn() {
		lst = new ArrayList<Passenger>();
		FileReader fr = null;
		try {
			fr = new FileReader(titanicTxt);
			try (BufferedReader br = new BufferedReader(fr)){
				String firstLine = br.readLine();
				String currentLine = br.readLine();
					while (currentLine!= null) {
					Passenger nP = passengerReadIn(currentLine);
					lst.add(nP);
					currentLine = br.readLine();
				}
				
			} catch (IOException e) {
				System.err.println(e.getMessage());
			}
		} catch (IOException e) {
			
			System.err.println(e.getMessage());
			
		} finally {
			
			try {
				if (fr != null) {
					fr.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
				
		}
		return lst;
	}
	/*
	 * Writes out the updated information about passengers.
	 */
	public void updateTitanicFile(List<Passenger> lst) {
		FileWriter fw = null;
		PrintWriter pw = null;
		this.lst = lst;
		try {
			fw = new FileWriter(titanicTxt);
			pw = new PrintWriter(fw);
			pw.println("Age|Cabin|Embarked|Fare|Name|Parch|PassengerId|Pclass|Sex|SibSp|Survived|Ticket|Title|Family_Size");
			for(int i = 0; i <lst.size(); i++) {
				pw.println(getFormattedPassengerInfo(lst.get(i)));
			}
		} catch (IOException e) {
			
			System.err.println(e.getMessage());
			
		} finally {
			
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
