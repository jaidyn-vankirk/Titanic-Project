package cs120.jvankirk20_fxml;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.chart.XYChart;
/*
 * Does the calculations for our total, pie chart, and bar graph.
 */
public class visualCalc {
	double total;
	double femaleSurvivors;
	double maleSurvivors;
	
	double class1;
	double class2;
	double class3;
	
	/*
	 * Calculates our total.
	 */
	public double totalPassengers(List<Passenger> lst) {
		total = 0;
		for (int i = 0; i <lst.size(); i++) {
			total++;
		}
		return total;
	}
	/*
	 * Adds one to our total
	 */
	public double addPass() {
		total ++;
		return total;
	}
	/*
	 * Subtracts one from our total.
	 */
	public double deletePass() {
		total --;
		return total;
	}
	/*
	 * Gets the amount of femal survivors.
	 */
	public double femaleSurvivors(List<Passenger> lst) {
		femaleSurvivors = 0;
		/*
		 * Gets list of survivors
		 */
		List<Passenger> survived = new ArrayList<Passenger>();
		for (int i = 0; i <lst.size(); i++) {
			if (lst.get(i).getSurvived() == 1) {
				survived.add(lst.get(i));
			}
		}
		/*
		 * Goes through and deciphers whic are female.
		 */
		for (int i = 0; i < survived.size(); i++) {
			if ((lst.get(i).getSex().compareTo("female")) == 0) {
				femaleSurvivors ++;
			}
		}
		return femaleSurvivors;
	}
	/*
	 * Checks and adds if it is a female survivor.
	 */
	public double addFemaleSurvivor(Passenger p) {
		if (p.getSurvived() == 1) {
			if ((p.getSex().compareTo("female")) == 0) {
				femaleSurvivors ++;
			}
		}
		return femaleSurvivors;
	}
	/*
	 * Checks and subtracts if it is a female survivor.
	 */
	public double deleteFemaleSurvivor(Passenger p) {
		if (p.getSurvived() == 1) {
			if ((p.getSex().compareTo("female")) == 0) {
				femaleSurvivors --;
			}
		}
		return femaleSurvivors;
	}
	/*
	 * Gets the amount of male survivors.
	 */
	public double maleSurvivors(List<Passenger> lst) {
		maleSurvivors = 0;
		/*
		 * Gets survivors
		 */
		List<Passenger> survived = new ArrayList<Passenger>();
		for (int i = 0; i <lst.size(); i++) {
			if (lst.get(i).getSurvived() == 1) {
				survived.add(lst.get(i));
			}
		}
		/*
		 * Deciphers which are male
		 */
		for (int i = 0; i < survived.size(); i++) {
			if ((lst.get(i).getSex().compareTo("male")) == 0) {
				maleSurvivors ++;
			}
		}
		return maleSurvivors;
	}
	/*
	 * Checks and adds if a male survivor.
	 */
	public double addMaleSurvivor(Passenger p) {
		if (p.getSurvived() == 1) {
			if ((p.getSex().compareTo("male")) == 0) {
				maleSurvivors ++;
			}
		}
		return femaleSurvivors;
	}
	/*
	 * Checks and deletes if male survivor.
	 */
	public double deleteMaleSurvivor(Passenger p) {
		if (p.getSurvived() == 1) {
			if ((p.getSex().compareTo("male")) == 0) {
				maleSurvivors --;
			}
		}
		return maleSurvivors;
	}
	/*
	 * Gets the classes percentages
	 */
	public void survivorsByClass(List<Passenger> lst) {
		double class1Original = 0;
		double class2Original = 0;
		double class3Original = 0;
		double survivedTotal = 0;
		/*
		 * Checks for survivors.
		 */
		List<Passenger> survived = new ArrayList<Passenger>();
		for (int i = 0; i <lst.size(); i++) {
			if (lst.get(i).getSurvived() == 1) {
				survived.add(lst.get(i));
				survivedTotal ++;
			}
		}
		/*
		 * Goes through survivors and deciphers which class they are in. The percentages then get updated.
		 */
		for (int i = 0; i < survived.size(); i++) {
			if (lst.get(i).getPClass() == 1.0) {
				class1Original++;
				class1 = class1Original/survivedTotal;
			}
			if (lst.get(i).getPClass() == 2.0) {
				class2Original++;
				class2 = class2Original/survivedTotal;
			}
			if (lst.get(i).getPClass() == 3.0) {
				class3Original++;
				class3 = class3Original/survivedTotal;
			}
		}
	}
	/*
	 * Getters for class percentages.
	 */
	public double getClass1() {
		return class1;
	}
	public double getClass2() {
		return class2;
	}
	public double getClass3() {
		return class3;
	}
	
	/*
	 * Deciphers survivors then creates an array list using the type of family size property.(Doesn't work that well, but I gave it my best effort.)
	 */
	public List<FamilySizes> survivorsByFamilySize(List<Passenger> lst){
		double survivedTotal = 0;
		List<Passenger> survived = new ArrayList<Passenger>();
		for (int i = 0; i <lst.size(); i++) {
			if (lst.get(i).getSurvived() == 1) {
				survived.add(lst.get(i));
				survivedTotal ++;
			}
		}
		List<FamilySizes> sizeTracker = new ArrayList<FamilySizes>();
		FamilySizes current = new FamilySizes(Double.toString(survived.get(0).getFamilySize()), survived.get(0).getFamilySize(), survivedTotal);
		sizeTracker.add(current);
		boolean alreadyInTheList = false;
		for (int i = 1; i < survived.size(); i++) {
			alreadyInTheList = false;
			for (int i2 = 0; i2 < sizeTracker.size(); i2++) {
				if (Double.toString(survived.get(i).getFamilySize()).compareTo(sizeTracker.get(i2).getNumberString()) == 0) {
					sizeTracker.get(i2).addPerson(survivedTotal);
					alreadyInTheList = true;
				}
			}
			if(alreadyInTheList != true) {
				current = new FamilySizes(Double.toString(survived.get(i).getFamilySize()), survived.get(i).getFamilySize(), survivedTotal);
				sizeTracker.add(current);
				alreadyInTheList = false;
			}
		}
		for(int i = 0; i < sizeTracker.size(); i ++) {
			System.out.println(sizeTracker.get(i).getNumberString());
		}
		return sizeTracker;
	}
}
