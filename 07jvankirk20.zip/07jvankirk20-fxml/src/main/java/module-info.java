module cs120.jvankirk20_fxml {
    requires javafx.controls;
    requires javafx.fxml;
	requires javafx.base;
	requires javafx.graphics;

    opens cs120.jvankirk20_fxml to javafx.fxml;
    exports cs120.jvankirk20_fxml;
}
